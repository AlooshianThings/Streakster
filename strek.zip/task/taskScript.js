let tasks = JSON.parse(localStorage.getItem('tasks')) || [];
const urlParams = new URLSearchParams(window.location.search);
const taskIndex = urlParams.get('task');
const task = tasks[taskIndex];
const streakCountElement = document.getElementById('streakCount');
const calendarElement = document.getElementById('calendar');
const taskHeader = document.getElementById('taskHeader');
const taskTitle = document.getElementById('taskTitle');

taskHeader.textContent = task.name;
taskTitle.textContent = `${task.name} - Streak Counter`;

const today = new Date().toISOString().split('T')[0];

function increaseStreak() {
    if (!task.dates.includes(today)) {
        task.streak++;
        task.dates.push(today);

        // Update local storage
        tasks[taskIndex] = task;
        localStorage.setItem('tasks', JSON.stringify(tasks));
        updateStreak();
        updateCalendar();
        checkRewards(task.streak, task.name);
    } else {
        alert("You've already updated the streak today.");
    }
}

function deleteStreak() {
    if (task.dates.length === 0) {
        alert('No streak days to delete.');
        return;
    }

    // Only allow deletion if today is the most recent streak day
    if (task.dates[task.dates.length - 1] === today) {
        task.dates.pop(); // Remove the most recent streak date
        task.streak = task.dates.length; // Update the streak count

        // Update local storage
        tasks[taskIndex] = task;
        localStorage.setItem('tasks', JSON.stringify(tasks));
        updateStreak();
        updateCalendar();
        alert('Last streak day deleted.');
    } else {
        alert("You can only delete today's streak.");
    }
}

function updateStreak() {
    streakCountElement.textContent = `${task.streak} day streak`;
}

function updateCalendar() {
    calendarElement.innerHTML = '';
    const today = new Date();
    const year = today.getFullYear();
    const month = today.getMonth();

    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);

    const daysInMonth = lastDay.getDate();
    const startDay = firstDay.getDay();
    const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    const weekdays = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

    const monthHeader = document.createElement('h2');
    monthHeader.textContent = `${months[month]} ${year}`;
    calendarElement.appendChild(monthHeader);

    const weekdayRow = document.createElement('div');
    weekdayRow.className = 'weekday-row';
    weekdays.forEach(day => {
        const dayDiv = document.createElement('div');
        dayDiv.textContent = day;
        weekdayRow.appendChild(dayDiv);
    });
    calendarElement.appendChild(weekdayRow);

    const calendarGrid = document.createElement('div');
    calendarGrid.className = 'calendar-grid';

    // Create empty cells for days before the first day of the month
    for (let i = 0; i < startDay; i++) {
        const emptyDiv = document.createElement('div');
        calendarGrid.appendChild(emptyDiv);
    }

    // Create cells for each day in the month
    for (let i = 1; i <= daysInMonth; i++) {
        const dayDiv = document.createElement('div');
        const date = `${year}-${(month + 1).toString().padStart(2, '0')}-${i.toString().padStart(2, '0')}`;
        dayDiv.textContent = i;

        if (task.dates.includes(date)) {
            dayDiv.classList.add('active');
        }

        calendarGrid.appendChild(dayDiv);
    }

    calendarElement.appendChild(calendarGrid);
}

function checkRewards(streakCount, activity) {
    const rewardsDiv = document.getElementById('rewards');
    rewardsDiv.innerHTML = '';

    let rewardMessage = '';
    const days = [1, 7, 14, 30, 60, 90, 180, 365, 548, 730];
    for (let i = 0; i < days.length; i++) {
        if (streakCount === days[i]) {
            rewardMessage = `Congratulations! You have reached a new milestone! You have been active for ${days[i]} days with ${activity}! Keep going!`;
            break;
        }
    }

    if (rewardMessage) {
        const rewardP = document.createElement('p');
        rewardP.textContent = rewardMessage;
        rewardsDiv.appendChild(rewardP);
    }
}

function deleteTask() {
    if (confirm('Are you sure you want to delete this task?')) {
        tasks.splice(taskIndex, 1); // Remove the task from the list
        localStorage.setItem('tasks', JSON.stringify(tasks)); // Update local storage
        alert('Task deleted successfully.');
        window.location.href = '../index.html'; // Redirect to home page
    }
}

function getDateFromString(dateString) {
    return new Date(dateString).toISOString().split('T')[0];
}

window.onload = () => {
    updateStreak();
    updateCalendar();
};
